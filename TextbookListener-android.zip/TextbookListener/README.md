# Textbook Listener (Android)
Paste or open text, listen offline, or save it as a WAV file in Music/TextbookAudio.
Build the APK with GitHub Actions: put these files in a GitHub repo, open the Actions tab,
run "Build APK", then download the "TextbookListener-apk" file and install it.
Or open the folder in Android Studio and press Run.
