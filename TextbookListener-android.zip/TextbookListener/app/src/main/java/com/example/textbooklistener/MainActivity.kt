package com.example.textbooklistener

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.text.InputType
import android.view.Gravity
import android.widget.*
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var titleBox: EditText
    private lateinit var textBox: EditText
    private lateinit var voiceSpinner: Spinner
    private lateinit var rateSpinner: Spinner
    private lateinit var status: TextView
    private var voices: List<Voice> = emptyList()
    private val rates = floatArrayOf(0.8f, 1f, 1.25f, 1.5f)
    @Volatile private var latch: CountDownLatch? = null
    @Volatile private var failed = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        tts = TextToSpeech(this, this)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(16), dp(16), dp(16))

        fun label(t: String) = TextView(this).apply { text = t; textSize = 14f; setPadding(0, dp(10), 0, dp(2)) }
        fun button(t: String, f: () -> Unit) = Button(this).apply { text = t; isAllCaps = false; setOnClickListener { f() } }

        titleBox = EditText(this).apply { hint = "Title (used as the file name)"; setSingleLine() }
        textBox = EditText(this).apply {
            hint = "Paste textbook text here…"; minLines = 8; gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        voiceSpinner = Spinner(this)
        rateSpinner = Spinner(this)
        rateSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("0.8×", "1×", "1.25×", "1.5×"))
        rateSpinner.setSelection(1)
        status = TextView(this).apply { textSize = 14f; setPadding(0, dp(10), 0, 0) }

        root.addView(titleBox)
        root.addView(textBox)
        root.addView(button("Open a .txt file") { pickFile() })
        root.addView(label("Voice (offline voices only)"))
        root.addView(voiceSpinner)
        root.addView(label("Speed"))
        root.addView(rateSpinner)
        root.addView(button("▶  Listen now") { listen() })
        root.addView(button("⏹  Stop") { tts.stop() })
        root.addView(button("💾  Save as audio (Music folder)") { save() })
        root.addView(button("Install / update voice data") {
            startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA))
        })
        root.addView(status)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onInit(code: Int) {
        if (code != TextToSpeech.SUCCESS) { status.text = "Text-to-speech is not available on this phone."; return }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { latch?.countDown() }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { failed = true; latch?.countDown() }
            override fun onError(id: String?, errorCode: Int) { failed = true; latch?.countDown() }
        })
        val all = try { tts.voices?.toList() ?: emptyList() } catch (e: Exception) { emptyList() }
        val lang = Locale.getDefault().language
        voices = all.filter { !it.isNetworkConnectionRequired }
            .sortedWith(compareBy({ it.locale.language != lang }, { it.locale.language != "en" }, { it.name }))
        if (voices.isEmpty()) {
            status.text = "No offline voices found. Tap \"Install / update voice data\"."
        } else {
            voiceSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
                voices.map { "${it.locale.displayName} · ${it.name}" })
            status.text = "Tip: try each voice with \"Listen now\" and pick the male voice you like best."
        }
    }

    private fun applyVoice() {
        if (voices.isNotEmpty()) tts.voice = voices[voiceSpinner.selectedItemPosition]
        tts.setSpeechRate(rates[rateSpinner.selectedItemPosition])
    }

    private fun split(t: String): List<String> {
        val out = mutableListOf<String>()
        var buf = StringBuilder()
        Regex("[^.!?\\n]+[.!?]*\\s*|\\n+").findAll(t.replace("\r", "")).forEach { m ->
            val s = m.value
            if (s.isBlank()) return@forEach
            if (buf.length + s.length > 1500 && buf.isNotEmpty()) { out.add(buf.toString().trim()); buf = StringBuilder() }
            buf.append(s)
        }
        if (buf.isNotBlank()) out.add(buf.toString().trim())
        return out
    }

    private fun listen() {
        val chunks = split(textBox.text.toString())
        if (chunks.isEmpty()) { status.text = "Please add some text first."; return }
        applyVoice()
        tts.stop()
        chunks.forEachIndexed { i, c ->
            tts.speak(c, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "p$i")
        }
        status.text = "Reading aloud…"
    }

    private fun save() {
        val chunks = split(textBox.text.toString())
        if (chunks.isEmpty()) { status.text = "Please add some text first."; return }
        tts.stop()
        applyVoice()
        val name = titleBox.text.toString().trim().ifEmpty { "Textbook" }.replace(Regex("[^\\w\\- ]"), "_")
        Thread {
            val files = ArrayList<File>()
            try {
                for ((i, c) in chunks.withIndex()) {
                    runOnUiThread { status.text = "Creating audio… ${i + 1}/${chunks.size}" }
                    val f = File(cacheDir, "c$i.wav"); files.add(f)
                    latch = CountDownLatch(1); failed = false
                    if (tts.synthesizeToFile(c, Bundle(), f, "s$i") != TextToSpeech.SUCCESS) throw Exception("Voice engine refused the text")
                    if (!latch!!.await(180, TimeUnit.SECONDS) || failed) throw Exception("Voice engine failed on part ${i + 1}")
                }
                // pass 1: measure
                var total = 0L; var rate = 22050; var ch = 1; var bits = 16
                for (f in files) { val w = readWav(f); rate = w.rate; ch = w.ch; bits = w.bits; total += w.data.size }
                val pause = ByteArray((rate * ch * (bits / 8) * 0.4).toInt() / (ch * (bits / 8)) * (ch * (bits / 8)))
                total += pause.size.toLong() * (files.size - 1)
                // pass 2: write into Music/TextbookAudio
                val values = ContentValues().apply {
                    put(MediaStore.Audio.Media.DISPLAY_NAME, "$name.wav")
                    put(MediaStore.Audio.Media.TITLE, name)
                    put(MediaStore.Audio.Media.MIME_TYPE, "audio/x-wav")
                    put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/TextbookAudio")
                }
                val uri = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values) ?: throw Exception("Could not create file")
                contentResolver.openOutputStream(uri)!!.use { out ->
                    out.write(header(rate, ch, bits, total.toInt()))
                    for ((i, f) in files.withIndex()) {
                        out.write(readWav(f).data)
                        if (i < files.size - 1) out.write(pause)
                    }
                }
                runOnUiThread { status.text = "Saved! Open your Music app → Music/TextbookAudio/$name.wav" }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Could not save: ${e.message}" }
            } finally {
                files.forEach { it.delete() }
            }
        }.start()
    }

    private class Wav(val rate: Int, val ch: Int, val bits: Int, val data: ByteArray)

    private fun readWav(f: File): Wav {
        val b = f.readBytes()
        val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
        var pos = 12; var rate = 22050; var ch = 1; var bits = 16
        while (pos + 8 <= b.size) {
            val id = String(b, pos, 4, Charsets.US_ASCII)
            var size = bb.getInt(pos + 4)
            if (id == "fmt ") { ch = bb.getShort(pos + 10).toInt(); rate = bb.getInt(pos + 12); bits = bb.getShort(pos + 22).toInt() }
            if (id == "data") {
                if (size <= 0 || pos + 8 + size > b.size) size = b.size - pos - 8
                return Wav(rate, ch, bits, b.copyOfRange(pos + 8, pos + 8 + size))
            }
            pos += 8 + size + (size and 1)
        }
        return Wav(rate, ch, bits, ByteArray(0))
    }

    private fun header(rate: Int, ch: Int, bits: Int, len: Int): ByteArray {
        val bb = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + len); bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()); bb.putInt(16); bb.putShort(1); bb.putShort(ch.toShort())
        bb.putInt(rate); bb.putInt(rate * ch * bits / 8); bb.putShort((ch * bits / 8).toShort()); bb.putShort(bits.toShort())
        bb.put("data".toByteArray()); bb.putInt(len)
        return bb.array()
    }

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "text/plain" }
        startActivityForResult(i, 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data ?: return
        if (req == 1 && res == RESULT_OK) {
            textBox.setText(contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: "")
        }
    }

    override fun onDestroy() { tts.shutdown(); super.onDestroy() }
}
